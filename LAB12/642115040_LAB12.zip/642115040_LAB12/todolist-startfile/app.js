const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const mongo = require('./config/db.js');
const Item = require('./model/listItem').Item;
const List = require('./model/listItem').List;
const lodash = require('lodash');

app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");


const item1 = new Item({
  name: "Welcome to your todolist!",
});
const item2 = new Item({
  name: "Hit the + button to add a new item",
});
const item3 = new Item({
  name: "<---Hit this to delete an item",
});
const defaultItems = [item1,item2,item3];


app.get('/', async(req,res) => {
  const items = await Item.find({});
    if(items.length == 0)
    {
      Item.insertMany(defaultItems)
      .then(() => {
        console.log("Added the 3 Welcome messages successfully");
        res.redirect('/');
      })
      .catch((err) => console.log(err));
    }
    else
    {
      res.render('list',{listTitle: "Today", newListItems: items })
    }
});


app.post('/',async (req,res) =>{
  const headerTitle = lodash.capitalize(req.body.list);
  if(headerTitle == 'Today'){
  const newItems = new Item({
      name: req.body.newItem
    });
    newItems.save()
    .then(() => res.redirect('/'));}
    else
    {
      const newItems = new Item({
        name: req.body.newItem
      });
      const updateList = await List.updateOne(
        { name: headerTitle },
        { $push: { items: newItems } });
        res.redirect('/' + headerTitle);
    }
  });

app.post('/delete',async (req,res)=>{
  let deleteItemId = req.body.checkbox;
  const listName = lodash.capitalize(req.body.listName);
  if(listName == 'Today'){
  const result = await Item.findByIdAndRemove(deleteItemId);
  res.redirect('/');
  }
  else{
    const updateList = await List.updateOne(
      { name: listName },
      { $pull: { items: { _id: deleteItemId } }
      
    });
    res.redirect('/'+ listName);
  }
})

app.get("/:customListName", async (req, res) => {
  const customListName = lodash.capitalize(req.params.customListName);
  const foundList = await List.findOne({ name: customListName });
  if (!foundList) {
    console.log("Does not exist");
    const list = new List({
      name: customListName,
      items: defaultItems
    });
    await list.save();
    res.redirect("/" + customListName);
  } else {
    console.log("Exist");
    res.render("list", {
      listTitle: foundList.name,
      newListItems: foundList.items
    });
  }
});


mongo.connect();

app.listen("3000", () => {
  console.log("Server is running on Port 3000.");
});