const express = require('express');

const app = express();

// app.get('/', (req, res) => {
//     res.send('Hello World!');
//   });

//   app.listen(3100, () => {
//     console.log('Server started on port 3100');
//   });
  

const fs = require('fs');
const port = 3100;

app.get('/', (req, res) => {
  fs.readFile('counter.txt', 'utf8', (err, data) => {
    if (err) {
      // If the file doesn't exist, create it with an initial count of 1
      if (err.code === 'ENOENT') {
        fs.writeFile('counter.txt', '1', 'utf8', (err) => {
          if (err) throw err;
          res.send('There has been 1 hit to this page');
        });
      } else {
        throw err;
      }
    } else {
      const count = parseInt(data) + 1;
      fs.writeFile('counter.txt', count.toString(), 'utf8', (err) => {
        if (err) throw err;
        res.send(`There has been ${count} hit to this page`);
      });
    }
  });
});

app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
