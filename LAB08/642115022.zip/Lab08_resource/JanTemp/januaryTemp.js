// Include the nodejs File system into your program
const fs = require("fs");

var january = "48,42,68\n";
january += "48,42,69\n";
january += "49,42,69\n";
january += "49,42,61\n";
january += "49,42,65\n";
january += "49,42,62\n";
january += "49,42,62\n";

//write
// fs.writeFile("sfjanaverges.txt", january, (err) => {
//   if (err) console.log(err);
//   else {
//     console.log("File written successfully\n");
//     console.log("The written has the following contents:");
//     console.log(fs.readFileSync("sfjanaverges.txt", "utf8"));
//   }
// });

//read
let index = 1;

var array = fs.readFileSync("sfjanaverges.txt").toString().split("\n");

array.forEach(element => {
    var array2 = element.toString().split(",");
    if (index != 8) {
        console.log("Day" + index);
        console.log("Mean: " + array2[0]);
        console.log("Low: " + array2[1]);
        console.log("High: " + array2[2] + "\n");
        index++
    }
});
