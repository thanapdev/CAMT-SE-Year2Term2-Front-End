const express = require('express');
const bodyParser = require('body-parser');
const app = express();

// app.get('/', (req, res) => {
//   res.send('Hello, world!');
// });

// Serve index.html file
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

// Setup body-parser middleware
app.use(bodyParser.urlencoded({ extended: true }));

// Handle POST request
app.post('/', (req, res) => {
  const weight = parseFloat(req.body.weight);
  const height = parseFloat(req.body.height);
  const bmi = weight / (height ** 2);
  res.send(`Your BMI is ${bmi}`);
});

// Start server
app.listen(3000, () => {
  console.log('Server started on port 3000');
});

